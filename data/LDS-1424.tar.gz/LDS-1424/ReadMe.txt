################################################################
Dataset Information
################################################################

Dataset Name:
iMN (Exp 2) - ALS, SMA and Control (unaffected) iMN cell lines differentiated from iPS cell lines using a long differentiation protocol - Proteomics

Dataset Description:

--Data Files in Package:
LV3A_PEPTIDE_MS2normalized_peptide_level.txt

--Metadata Files In Package:
Differentiated_Cell_Metadata.txt

################################################################
Center-specific Information
################################################################

Center-specific Name:
NeuroLINCS

Center-specific Dataset ID:
LDS-1424

Center-specific Dataset Link:


################################################################
Assay Information
################################################################

Assay Protocol:

Date Updated:

Date Retrieved from Center:

################################################################
Metadata Information
################################################################

Metadata information regarding the entities used in the experiments is included in the accompanied metadata. A metadata file per entity category is included in the package. For example, the metadata for all the cell lines that were used in the dataset are included in the Cell_Lines_Metadata.txt file.
Descriptions for each metadata field can be found here: http://www.lincsproject.org/data/data-standards/
